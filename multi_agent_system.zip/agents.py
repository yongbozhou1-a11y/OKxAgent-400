import time
import random

class Agent:
    def __init__(self, name):
        self.name = name
        self.state = "idle"

    def perform_task(self, task):
        self.state = "busy"
        print(f"{self.name} performing: {task}")
        time.sleep(random.randint(1, 3))
        self.state = "idle"
        print(f"{self.name} finished: {task}")

    def communicate(self, message, other_agent):
        print(f"{self.name} -> {other_agent.name}: {message}")
        other_agent.receive_message(message)

    def receive_message(self, message):
        print(f"{self.name} received: {message}")
