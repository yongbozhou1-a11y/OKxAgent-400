import threading
import time
from agents import Agent
from manager import TaskManager

class MultiAgentSystem:
    def __init__(self):
        self.agents = [
            Agent("Data Collector"),
            Agent("Data Analyzer"),
            Agent("Report Generator"),
            Agent("Feedback Sender"),
        ]
        self.manager = TaskManager(self.agents)

    def run(self):
        while True:
            self.manager.assign_tasks()
            time.sleep(5)

if __name__ == "__main__":
    system = MultiAgentSystem()
    t = threading.Thread(target=system.run)
    t.start()
