import random

class TaskManager:
    def __init__(self, agents):
        self.agents = agents
        self.tasks = [
            "Collect Data",
            "Analyze Data",
            "Generate Report",
            "Send Feedback",
        ]

    def assign_tasks(self):
        for agent in self.agents:
            if agent.state == "idle":
                task = random.choice(self.tasks)
                print(f"Assigning {task} to {agent.name}")
                agent.perform_task(task)

                if task == "Analyze Data":
                    agent.communicate(
                        "Need raw data",
                        self.agents[0]
                    )
